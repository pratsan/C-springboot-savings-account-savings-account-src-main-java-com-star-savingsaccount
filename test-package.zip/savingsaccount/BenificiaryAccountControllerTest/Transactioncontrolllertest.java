/**
 * 
 */
package com.star.savingsaccount.BenificiaryAccountControllerTest;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.star.savingsaccount.controller.TransactionController;
import com.star.savingsaccount.dto.HistoryReqDto;
import com.star.savingsaccount.dto.HistoryRespDto;
import com.star.savingsaccount.exception.InvalidStatusDateException;
import com.star.savingsaccount.exception.RecordNotFoundException;
import com.star.savingsaccount.exception.TransactionException;
import com.star.savingsaccount.service.TransactionHistoryService;

/**
 * @author User1
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class Transactioncontrolllertest {

	@InjectMocks
	TransactionController transactionController;
	@Mock
	TransactionHistoryService transactionHistoryService;

	@Test
	public void transactionHistoryTest() throws TransactionException ,InvalidStatusDateException,RecordNotFoundException {
		HistoryReqDto historyReqDto = new HistoryReqDto();
		historyReqDto.setFromDate("2020-03-11");
		historyReqDto.setTodate("2020-03-16");

		HistoryRespDto historyRespDto = new HistoryRespDto();
		historyRespDto.setUserName("uma");
		historyRespDto.setAddress("banglore");
		Mockito.when(transactionHistoryService.transactionHistory(1L, historyReqDto)).thenReturn(historyRespDto);
		ResponseEntity<HistoryRespDto> result = transactionController.transactionHistory(1L, historyReqDto);
		assertEquals(HttpStatus.OK, result.getStatusCode());

	}

}
