/**
 * 
 */
package com.star.savingsaccount.serviceImpl;

import static org.junit.Assert.assertEquals;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.star.savingsaccount.dto.HistoryReqDto;
import com.star.savingsaccount.dto.HistoryRespDto;
import com.star.savingsaccount.dto.TransactionHistoryDto;
import com.star.savingsaccount.entity.TransactionHistory;
import com.star.savingsaccount.entity.User;
import com.star.savingsaccount.repository.TransactionHistoryRepository;
import com.star.savingsaccount.service.TransactionHistoryServiceImpl;

/**
 * @author User1
 *
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class TransactionHistoryServiceImplTest {

	@InjectMocks
	TransactionHistoryServiceImpl transactionHistoryServiceImpl;
	@Mock
	TransactionHistoryRepository transactionHistoryRepository;

	@SuppressWarnings("unchecked")
	@Test
	public void transactionHistoryTest() {

		try {

			String fmDate = "2020-03-18 16:56:14";
			String todate = "2020-03-18 16:56:14";
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			Date fromDate = format.parse(fmDate);
			Date tdate = format.parse(todate);

			HistoryReqDto historyReqDto = new HistoryReqDto();
			historyReqDto.setFromDate("");
			historyReqDto.setTodate("");
			HistoryRespDto historyRespDto = new HistoryRespDto();
			historyRespDto.setAccountNumber("000123a");
			historyRespDto.setBalance(1000.00);

			User user = new User();
			user.setEmail("deepa@gmail.com");
			user.setPassword("123abc");
			TransactionHistoryDto transactionHistoryDto = new TransactionHistoryDto();

			transactionHistoryDto.setDate("2020-03-17");
			transactionHistoryDto.setRefNumber("123av2");
			TransactionHistory transactionHistory = new TransactionHistory();
			transactionHistory.setRefNumber("123abc");
			transactionHistory.setAmount(10000.00);
			List<TransactionHistory> transactionHistory1 = transactionHistoryRepository.findByIdAndTransactionDate(1L,
					fromDate, tdate);
			transactionHistory1.add(transactionHistory);
			List<TransactionHistoryDto> trxDtos = new ArrayList<>();

			Mockito.when(transactionHistoryRepository.findByIdAndTransactionDate(1L, fromDate, tdate))
					.thenReturn((List<TransactionHistory>) transactionHistory);
			HistoryRespDto result = transactionHistoryServiceImpl.transactionHistory(1L, historyReqDto);

			assertEquals("success", result.getBalance());
		} catch (Exception e) {
		}

	}

}
