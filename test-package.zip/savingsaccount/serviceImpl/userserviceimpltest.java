/**
 * 
 */
package com.star.savingsaccount.serviceImpl;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;

import com.star.savingsaccount.dto.ResponseDto;
import com.star.savingsaccount.dto.UserDto;
import com.star.savingsaccount.entity.User;
import com.star.savingsaccount.repository.UserRepository;
import com.star.savingsaccount.service.UserServiceImpl;

/**
 * @author User1
 *
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class userserviceimpltest {

	@InjectMocks
	UserServiceImpl userServiceImpl;

	@Mock
	UserRepository userRepository;

	@Test
	public void userLoginTest() {
		ResponseDto responseDto = new ResponseDto();
		responseDto.setStatusCode(HttpStatus.BAD_REQUEST.value());
		responseDto.setStatusMessage("Please provide the required  data");

		User user = new User();
		user.setEmail("abc@gmail.com");
		user.setPassword("asdf");

		UserDto userDto = new UserDto();
		userDto.setPassword("");
		userDto.setEmail("");
		Mockito.when(userRepository.findByEmailAndPassword("abc@gmail.com", "asdf")).thenReturn(user);
		ResponseDto result = userServiceImpl.userLogin(userDto);

		assertEquals("Please provide the required  data", result.getStatusMessage());
	}

}
